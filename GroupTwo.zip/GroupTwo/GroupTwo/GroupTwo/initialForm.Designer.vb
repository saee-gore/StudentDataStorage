﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class InitialForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnNewStudent = New System.Windows.Forms.Button()
        Me.btnEditStudent = New System.Windows.Forms.Button()
        Me.btnDeleteStudent = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'btnNewStudent
        '
        Me.btnNewStudent.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnNewStudent.Location = New System.Drawing.Point(12, 12)
        Me.btnNewStudent.Name = "btnNewStudent"
        Me.btnNewStudent.Size = New System.Drawing.Size(241, 29)
        Me.btnNewStudent.TabIndex = 0
        Me.btnNewStudent.Text = "New Student"
        Me.btnNewStudent.UseVisualStyleBackColor = True
        '
        'btnEditStudent
        '
        Me.btnEditStudent.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnEditStudent.Location = New System.Drawing.Point(12, 47)
        Me.btnEditStudent.Name = "btnEditStudent"
        Me.btnEditStudent.Size = New System.Drawing.Size(241, 29)
        Me.btnEditStudent.TabIndex = 1
        Me.btnEditStudent.Text = "Edit a Student"
        Me.btnEditStudent.UseVisualStyleBackColor = True
        '
        'btnDeleteStudent
        '
        Me.btnDeleteStudent.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnDeleteStudent.Location = New System.Drawing.Point(12, 82)
        Me.btnDeleteStudent.Name = "btnDeleteStudent"
        Me.btnDeleteStudent.Size = New System.Drawing.Size(241, 29)
        Me.btnDeleteStudent.TabIndex = 2
        Me.btnDeleteStudent.Text = "Delete a Student"
        Me.btnDeleteStudent.UseVisualStyleBackColor = True
        '
        'InitialForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(266, 121)
        Me.Controls.Add(Me.btnDeleteStudent)
        Me.Controls.Add(Me.btnEditStudent)
        Me.Controls.Add(Me.btnNewStudent)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D
        Me.MaximizeBox = False
        Me.Name = "InitialForm"
        Me.Text = "Open a form"
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents btnNewStudent As Button
    Friend WithEvents btnEditStudent As Button
    Friend WithEvents btnDeleteStudent As Button
End Class
