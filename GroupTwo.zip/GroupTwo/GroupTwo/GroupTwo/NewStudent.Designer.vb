﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class NewStudent
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.dtpDate = New System.Windows.Forms.DateTimePicker()
        Me.cbIstudent = New System.Windows.Forms.CheckBox()
        Me.cbTstudent = New System.Windows.Forms.CheckBox()
        Me.btnSubmit = New System.Windows.Forms.Button()
        Me.btnSuggest = New System.Windows.Forms.Button()
        Me.rbMale = New System.Windows.Forms.RadioButton()
        Me.rbFemale = New System.Windows.Forms.RadioButton()
        Me.rbOther = New System.Windows.Forms.RadioButton()
        Me.lblUid = New System.Windows.Forms.Label()
        Me.txtUid = New System.Windows.Forms.TextBox()
        Me.lblLname = New System.Windows.Forms.Label()
        Me.lblFname = New System.Windows.Forms.Label()
        Me.lblMname = New System.Windows.Forms.Label()
        Me.lblUemail = New System.Windows.Forms.Label()
        Me.txtLname = New System.Windows.Forms.TextBox()
        Me.txtFname = New System.Windows.Forms.TextBox()
        Me.txtMname = New System.Windows.Forms.TextBox()
        Me.txtUemail = New System.Windows.Forms.TextBox()
        Me.lblDomain = New System.Windows.Forms.Label()
        Me.lblCnumber = New System.Windows.Forms.Label()
        Me.lblDb = New System.Windows.Forms.Label()
        Me.lblGender = New System.Windows.Forms.Label()
        Me.lblEthnicity = New System.Windows.Forms.Label()
        Me.txtEthnicity = New System.Windows.Forms.TextBox()
        Me.lblYear = New System.Windows.Forms.Label()
        Me.txtYear = New System.Windows.Forms.TextBox()
        Me.lblMajor = New System.Windows.Forms.Label()
        Me.txtMajor = New System.Windows.Forms.TextBox()
        Me.txtCtransfer = New System.Windows.Forms.TextBox()
        Me.txtCearned = New System.Windows.Forms.TextBox()
        Me.txtGpa = New System.Windows.Forms.TextBox()
        Me.txtTuition = New System.Windows.Forms.TextBox()
        Me.txtScholarship = New System.Windows.Forms.TextBox()
        Me.lblCtransfer = New System.Windows.Forms.Label()
        Me.lblCearned = New System.Windows.Forms.Label()
        Me.lblGpa = New System.Windows.Forms.Label()
        Me.lblTuition = New System.Windows.Forms.Label()
        Me.lblScholarship = New System.Windows.Forms.Label()
        Me.lblWarning = New System.Windows.Forms.Label()
        Me.txtCnumber = New System.Windows.Forms.MaskedTextBox()
        Me.SuspendLayout()
        '
        'dtpDate
        '
        Me.dtpDate.Location = New System.Drawing.Point(92, 338)
        Me.dtpDate.Margin = New System.Windows.Forms.Padding(2)
        Me.dtpDate.Name = "dtpDate"
        Me.dtpDate.Size = New System.Drawing.Size(188, 20)
        Me.dtpDate.TabIndex = 0
        '
        'cbIstudent
        '
        Me.cbIstudent.AutoSize = True
        Me.cbIstudent.Location = New System.Drawing.Point(20, 499)
        Me.cbIstudent.Margin = New System.Windows.Forms.Padding(2)
        Me.cbIstudent.Name = "cbIstudent"
        Me.cbIstudent.Size = New System.Drawing.Size(124, 17)
        Me.cbIstudent.TabIndex = 1
        Me.cbIstudent.Text = "International Student"
        Me.cbIstudent.UseVisualStyleBackColor = True
        '
        'cbTstudent
        '
        Me.cbTstudent.AutoSize = True
        Me.cbTstudent.Location = New System.Drawing.Point(20, 607)
        Me.cbTstudent.Margin = New System.Windows.Forms.Padding(2)
        Me.cbTstudent.Name = "cbTstudent"
        Me.cbTstudent.Size = New System.Drawing.Size(105, 17)
        Me.cbTstudent.TabIndex = 2
        Me.cbTstudent.Text = "Transfer Student"
        Me.cbTstudent.UseVisualStyleBackColor = True
        '
        'btnSubmit
        '
        Me.btnSubmit.Location = New System.Drawing.Point(176, 817)
        Me.btnSubmit.Margin = New System.Windows.Forms.Padding(2)
        Me.btnSubmit.Name = "btnSubmit"
        Me.btnSubmit.Size = New System.Drawing.Size(56, 32)
        Me.btnSubmit.TabIndex = 3
        Me.btnSubmit.Text = "Submit"
        Me.btnSubmit.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.btnSubmit.UseVisualStyleBackColor = True
        '
        'btnSuggest
        '
        Me.btnSuggest.Location = New System.Drawing.Point(14, 243)
        Me.btnSuggest.Margin = New System.Windows.Forms.Padding(2)
        Me.btnSuggest.Name = "btnSuggest"
        Me.btnSuggest.Size = New System.Drawing.Size(64, 26)
        Me.btnSuggest.TabIndex = 4
        Me.btnSuggest.Text = "Suggest"
        Me.btnSuggest.UseVisualStyleBackColor = True
        '
        'rbMale
        '
        Me.rbMale.AutoSize = True
        Me.rbMale.Location = New System.Drawing.Point(20, 418)
        Me.rbMale.Margin = New System.Windows.Forms.Padding(2)
        Me.rbMale.Name = "rbMale"
        Me.rbMale.Size = New System.Drawing.Size(48, 17)
        Me.rbMale.TabIndex = 5
        Me.rbMale.TabStop = True
        Me.rbMale.Text = "Male"
        Me.rbMale.UseVisualStyleBackColor = True
        '
        'rbFemale
        '
        Me.rbFemale.AutoSize = True
        Me.rbFemale.Location = New System.Drawing.Point(92, 418)
        Me.rbFemale.Margin = New System.Windows.Forms.Padding(2)
        Me.rbFemale.Name = "rbFemale"
        Me.rbFemale.Size = New System.Drawing.Size(59, 17)
        Me.rbFemale.TabIndex = 6
        Me.rbFemale.TabStop = True
        Me.rbFemale.Text = "Female"
        Me.rbFemale.UseVisualStyleBackColor = True
        '
        'rbOther
        '
        Me.rbOther.AutoSize = True
        Me.rbOther.Location = New System.Drawing.Point(176, 418)
        Me.rbOther.Margin = New System.Windows.Forms.Padding(2)
        Me.rbOther.Name = "rbOther"
        Me.rbOther.Size = New System.Drawing.Size(51, 17)
        Me.rbOther.TabIndex = 7
        Me.rbOther.TabStop = True
        Me.rbOther.Text = "Other"
        Me.rbOther.UseVisualStyleBackColor = True
        '
        'lblUid
        '
        Me.lblUid.AutoSize = True
        Me.lblUid.Location = New System.Drawing.Point(17, 19)
        Me.lblUid.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblUid.Name = "lblUid"
        Me.lblUid.Size = New System.Drawing.Size(55, 13)
        Me.lblUid.TabIndex = 8
        Me.lblUid.Text = "Unique ID"
        '
        'txtUid
        '
        Me.txtUid.Location = New System.Drawing.Point(79, 19)
        Me.txtUid.Margin = New System.Windows.Forms.Padding(2)
        Me.txtUid.Name = "txtUid"
        Me.txtUid.Size = New System.Drawing.Size(95, 20)
        Me.txtUid.TabIndex = 9
        '
        'lblLname
        '
        Me.lblLname.AutoSize = True
        Me.lblLname.Location = New System.Drawing.Point(17, 62)
        Me.lblLname.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblLname.Name = "lblLname"
        Me.lblLname.Size = New System.Drawing.Size(62, 13)
        Me.lblLname.TabIndex = 10
        Me.lblLname.Text = "*Last Name"
        '
        'lblFname
        '
        Me.lblFname.AutoSize = True
        Me.lblFname.Location = New System.Drawing.Point(17, 110)
        Me.lblFname.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblFname.Name = "lblFname"
        Me.lblFname.Size = New System.Drawing.Size(61, 13)
        Me.lblFname.TabIndex = 11
        Me.lblFname.Text = "*First Name"
        '
        'lblMname
        '
        Me.lblMname.AutoSize = True
        Me.lblMname.Location = New System.Drawing.Point(17, 162)
        Me.lblMname.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblMname.Name = "lblMname"
        Me.lblMname.Size = New System.Drawing.Size(120, 13)
        Me.lblMname.TabIndex = 12
        Me.lblMname.Text = "Middle Name(s)/Initial(s)"
        '
        'lblUemail
        '
        Me.lblUemail.AutoSize = True
        Me.lblUemail.Location = New System.Drawing.Point(90, 226)
        Me.lblUemail.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblUemail.Name = "lblUemail"
        Me.lblUemail.Size = New System.Drawing.Size(84, 13)
        Me.lblUemail.TabIndex = 13
        Me.lblUemail.Text = "*University email"
        '
        'txtLname
        '
        Me.txtLname.Location = New System.Drawing.Point(20, 78)
        Me.txtLname.Margin = New System.Windows.Forms.Padding(2)
        Me.txtLname.Name = "txtLname"
        Me.txtLname.Size = New System.Drawing.Size(206, 20)
        Me.txtLname.TabIndex = 14
        '
        'txtFname
        '
        Me.txtFname.Location = New System.Drawing.Point(20, 126)
        Me.txtFname.Margin = New System.Windows.Forms.Padding(2)
        Me.txtFname.Name = "txtFname"
        Me.txtFname.Size = New System.Drawing.Size(206, 20)
        Me.txtFname.TabIndex = 15
        '
        'txtMname
        '
        Me.txtMname.Location = New System.Drawing.Point(20, 188)
        Me.txtMname.Margin = New System.Windows.Forms.Padding(2)
        Me.txtMname.Name = "txtMname"
        Me.txtMname.Size = New System.Drawing.Size(206, 20)
        Me.txtMname.TabIndex = 16
        '
        'txtUemail
        '
        Me.txtUemail.Location = New System.Drawing.Point(92, 247)
        Me.txtUemail.Margin = New System.Windows.Forms.Padding(2)
        Me.txtUemail.Name = "txtUemail"
        Me.txtUemail.Size = New System.Drawing.Size(112, 20)
        Me.txtUemail.TabIndex = 17
        Me.txtUemail.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'lblDomain
        '
        Me.lblDomain.AutoSize = True
        Me.lblDomain.Location = New System.Drawing.Point(208, 250)
        Me.lblDomain.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblDomain.Name = "lblDomain"
        Me.lblDomain.Size = New System.Drawing.Size(62, 13)
        Me.lblDomain.TabIndex = 18
        Me.lblDomain.Text = "@usca.edu"
        '
        'lblCnumber
        '
        Me.lblCnumber.AutoSize = True
        Me.lblCnumber.Location = New System.Drawing.Point(17, 294)
        Me.lblCnumber.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblCnumber.Name = "lblCnumber"
        Me.lblCnumber.Size = New System.Drawing.Size(38, 13)
        Me.lblCnumber.TabIndex = 19
        Me.lblCnumber.Text = "Phone"
        '
        'lblDb
        '
        Me.lblDb.AutoSize = True
        Me.lblDb.Location = New System.Drawing.Point(17, 338)
        Me.lblDb.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblDb.Name = "lblDb"
        Me.lblDb.Size = New System.Drawing.Size(66, 13)
        Me.lblDb.TabIndex = 21
        Me.lblDb.Text = "Date of Birth"
        '
        'lblGender
        '
        Me.lblGender.AutoSize = True
        Me.lblGender.Location = New System.Drawing.Point(17, 383)
        Me.lblGender.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblGender.Name = "lblGender"
        Me.lblGender.Size = New System.Drawing.Size(42, 13)
        Me.lblGender.TabIndex = 22
        Me.lblGender.Text = "Gender"
        '
        'lblEthnicity
        '
        Me.lblEthnicity.AutoSize = True
        Me.lblEthnicity.Location = New System.Drawing.Point(37, 461)
        Me.lblEthnicity.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblEthnicity.Name = "lblEthnicity"
        Me.lblEthnicity.Size = New System.Drawing.Size(47, 13)
        Me.lblEthnicity.TabIndex = 23
        Me.lblEthnicity.Text = "Ethnicity"
        '
        'txtEthnicity
        '
        Me.txtEthnicity.Location = New System.Drawing.Point(92, 461)
        Me.txtEthnicity.Margin = New System.Windows.Forms.Padding(2)
        Me.txtEthnicity.Name = "txtEthnicity"
        Me.txtEthnicity.Size = New System.Drawing.Size(188, 20)
        Me.txtEthnicity.TabIndex = 24
        '
        'lblYear
        '
        Me.lblYear.AutoSize = True
        Me.lblYear.Location = New System.Drawing.Point(17, 537)
        Me.lblYear.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblYear.Name = "lblYear"
        Me.lblYear.Size = New System.Drawing.Size(78, 13)
        Me.lblYear.TabIndex = 25
        Me.lblYear.Text = "Year in College"
        '
        'txtYear
        '
        Me.txtYear.Location = New System.Drawing.Point(111, 535)
        Me.txtYear.Margin = New System.Windows.Forms.Padding(2)
        Me.txtYear.Name = "txtYear"
        Me.txtYear.Size = New System.Drawing.Size(76, 20)
        Me.txtYear.TabIndex = 26
        '
        'lblMajor
        '
        Me.lblMajor.AutoSize = True
        Me.lblMajor.Location = New System.Drawing.Point(50, 570)
        Me.lblMajor.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblMajor.Name = "lblMajor"
        Me.lblMajor.Size = New System.Drawing.Size(33, 13)
        Me.lblMajor.TabIndex = 27
        Me.lblMajor.Text = "Major"
        '
        'txtMajor
        '
        Me.txtMajor.Location = New System.Drawing.Point(111, 570)
        Me.txtMajor.Margin = New System.Windows.Forms.Padding(2)
        Me.txtMajor.Name = "txtMajor"
        Me.txtMajor.Size = New System.Drawing.Size(169, 20)
        Me.txtMajor.TabIndex = 28
        '
        'txtCtransfer
        '
        Me.txtCtransfer.Location = New System.Drawing.Point(193, 642)
        Me.txtCtransfer.Margin = New System.Windows.Forms.Padding(2)
        Me.txtCtransfer.Name = "txtCtransfer"
        Me.txtCtransfer.Size = New System.Drawing.Size(87, 20)
        Me.txtCtransfer.TabIndex = 29
        '
        'txtCearned
        '
        Me.txtCearned.Location = New System.Drawing.Point(193, 678)
        Me.txtCearned.Margin = New System.Windows.Forms.Padding(2)
        Me.txtCearned.Name = "txtCearned"
        Me.txtCearned.Size = New System.Drawing.Size(87, 20)
        Me.txtCearned.TabIndex = 30
        '
        'txtGpa
        '
        Me.txtGpa.Location = New System.Drawing.Point(193, 712)
        Me.txtGpa.Margin = New System.Windows.Forms.Padding(2)
        Me.txtGpa.Name = "txtGpa"
        Me.txtGpa.Size = New System.Drawing.Size(87, 20)
        Me.txtGpa.TabIndex = 31
        '
        'txtTuition
        '
        Me.txtTuition.Location = New System.Drawing.Point(193, 748)
        Me.txtTuition.Margin = New System.Windows.Forms.Padding(2)
        Me.txtTuition.Name = "txtTuition"
        Me.txtTuition.Size = New System.Drawing.Size(87, 20)
        Me.txtTuition.TabIndex = 32
        '
        'txtScholarship
        '
        Me.txtScholarship.Location = New System.Drawing.Point(193, 782)
        Me.txtScholarship.Margin = New System.Windows.Forms.Padding(2)
        Me.txtScholarship.Name = "txtScholarship"
        Me.txtScholarship.Size = New System.Drawing.Size(87, 20)
        Me.txtScholarship.TabIndex = 33
        '
        'lblCtransfer
        '
        Me.lblCtransfer.AutoSize = True
        Me.lblCtransfer.Location = New System.Drawing.Point(78, 646)
        Me.lblCtransfer.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblCtransfer.Name = "lblCtransfer"
        Me.lblCtransfer.Size = New System.Drawing.Size(92, 13)
        Me.lblCtransfer.TabIndex = 34
        Me.lblCtransfer.Text = "Credits transferred"
        '
        'lblCearned
        '
        Me.lblCearned.AutoSize = True
        Me.lblCearned.Location = New System.Drawing.Point(37, 682)
        Me.lblCearned.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblCearned.Name = "lblCearned"
        Me.lblCearned.Size = New System.Drawing.Size(134, 13)
        Me.lblCearned.TabIndex = 35
        Me.lblCearned.Text = "Credits earned at institution"
        '
        'lblGpa
        '
        Me.lblGpa.AutoSize = True
        Me.lblGpa.Location = New System.Drawing.Point(128, 714)
        Me.lblGpa.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblGpa.Name = "lblGpa"
        Me.lblGpa.Size = New System.Drawing.Size(29, 13)
        Me.lblGpa.TabIndex = 36
        Me.lblGpa.Text = "GPA"
        '
        'lblTuition
        '
        Me.lblTuition.AutoSize = True
        Me.lblTuition.Location = New System.Drawing.Point(36, 750)
        Me.lblTuition.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblTuition.Name = "lblTuition"
        Me.lblTuition.Size = New System.Drawing.Size(151, 13)
        Me.lblTuition.TabIndex = 37
        Me.lblTuition.Text = "Tuition before scholarships    $"
        '
        'lblScholarship
        '
        Me.lblScholarship.AutoSize = True
        Me.lblScholarship.Location = New System.Drawing.Point(109, 782)
        Me.lblScholarship.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblScholarship.Name = "lblScholarship"
        Me.lblScholarship.Size = New System.Drawing.Size(80, 13)
        Me.lblScholarship.TabIndex = 38
        Me.lblScholarship.Text = "Scholarhips    $"
        '
        'lblWarning
        '
        Me.lblWarning.AutoSize = True
        Me.lblWarning.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblWarning.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.lblWarning.Location = New System.Drawing.Point(18, 825)
        Me.lblWarning.Name = "lblWarning"
        Me.lblWarning.Size = New System.Drawing.Size(133, 24)
        Me.lblWarning.TabIndex = 39
        Me.lblWarning.Text = "If Students.xlsx is open, please" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "close it before clicking Submit." & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        '
        'txtCnumber
        '
        Me.txtCnumber.Location = New System.Drawing.Point(92, 291)
        Me.txtCnumber.Mask = "(999) 000-0000"
        Me.txtCnumber.Name = "txtCnumber"
        Me.txtCnumber.Size = New System.Drawing.Size(112, 20)
        Me.txtCnumber.TabIndex = 40
        '
        'NewStudent
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.AutoScroll = True
        Me.ClientSize = New System.Drawing.Size(304, 631)
        Me.Controls.Add(Me.txtCnumber)
        Me.Controls.Add(Me.lblWarning)
        Me.Controls.Add(Me.lblScholarship)
        Me.Controls.Add(Me.lblTuition)
        Me.Controls.Add(Me.lblGpa)
        Me.Controls.Add(Me.lblCearned)
        Me.Controls.Add(Me.lblCtransfer)
        Me.Controls.Add(Me.txtScholarship)
        Me.Controls.Add(Me.txtTuition)
        Me.Controls.Add(Me.txtGpa)
        Me.Controls.Add(Me.txtCearned)
        Me.Controls.Add(Me.txtCtransfer)
        Me.Controls.Add(Me.txtMajor)
        Me.Controls.Add(Me.lblMajor)
        Me.Controls.Add(Me.txtYear)
        Me.Controls.Add(Me.lblYear)
        Me.Controls.Add(Me.txtEthnicity)
        Me.Controls.Add(Me.lblEthnicity)
        Me.Controls.Add(Me.lblGender)
        Me.Controls.Add(Me.lblDb)
        Me.Controls.Add(Me.lblCnumber)
        Me.Controls.Add(Me.lblDomain)
        Me.Controls.Add(Me.txtUemail)
        Me.Controls.Add(Me.txtMname)
        Me.Controls.Add(Me.txtFname)
        Me.Controls.Add(Me.txtLname)
        Me.Controls.Add(Me.lblUemail)
        Me.Controls.Add(Me.lblMname)
        Me.Controls.Add(Me.lblFname)
        Me.Controls.Add(Me.lblLname)
        Me.Controls.Add(Me.txtUid)
        Me.Controls.Add(Me.lblUid)
        Me.Controls.Add(Me.rbOther)
        Me.Controls.Add(Me.rbFemale)
        Me.Controls.Add(Me.rbMale)
        Me.Controls.Add(Me.btnSuggest)
        Me.Controls.Add(Me.btnSubmit)
        Me.Controls.Add(Me.cbTstudent)
        Me.Controls.Add(Me.cbIstudent)
        Me.Controls.Add(Me.dtpDate)
        Me.Margin = New System.Windows.Forms.Padding(2)
        Me.Name = "NewStudent"
        Me.Text = "New Student"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents dtpDate As DateTimePicker
    Friend WithEvents cbIstudent As CheckBox
    Friend WithEvents cbTstudent As CheckBox
    Friend WithEvents btnSubmit As Button
    Friend WithEvents btnSuggest As Button
    Friend WithEvents rbMale As RadioButton
    Friend WithEvents rbFemale As RadioButton
    Friend WithEvents rbOther As RadioButton
    Friend WithEvents lblUid As Label
    Friend WithEvents txtUid As TextBox
    Friend WithEvents lblLname As Label
    Friend WithEvents lblFname As Label
    Friend WithEvents lblMname As Label
    Friend WithEvents lblUemail As Label
    Friend WithEvents txtLname As TextBox
    Friend WithEvents txtFname As TextBox
    Friend WithEvents txtMname As TextBox
    Friend WithEvents txtUemail As TextBox
    Friend WithEvents lblDomain As Label
    Friend WithEvents lblCnumber As Label
    Friend WithEvents lblDb As Label
    Friend WithEvents lblGender As Label
    Friend WithEvents lblEthnicity As Label
    Friend WithEvents txtEthnicity As TextBox
    Friend WithEvents lblYear As Label
    Friend WithEvents txtYear As TextBox
    Friend WithEvents lblMajor As Label
    Friend WithEvents txtMajor As TextBox
    Friend WithEvents txtCtransfer As TextBox
    Friend WithEvents txtCearned As TextBox
    Friend WithEvents txtGpa As TextBox
    Friend WithEvents txtTuition As TextBox
    Friend WithEvents txtScholarship As TextBox
    Friend WithEvents lblCtransfer As Label
    Friend WithEvents lblCearned As Label
    Friend WithEvents lblGpa As Label
    Friend WithEvents lblTuition As Label
    Friend WithEvents lblScholarship As Label
    Friend WithEvents lblWarning As Label
    Friend WithEvents txtCnumber As MaskedTextBox
End Class
