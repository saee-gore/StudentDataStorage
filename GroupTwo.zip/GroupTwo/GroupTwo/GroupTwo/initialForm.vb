﻿Public Class InitialForm
    Private Sub btnNewStudent_Click(sender As Object, e As EventArgs) Handles btnNewStudent.Click
        Dim oNewStudentForm = New NewStudent
        oNewStudentForm.Show()
    End Sub

    Private Sub btnEditStudent_Click(sender As Object, e As EventArgs) Handles btnEditStudent.Click
        Dim oEditStudent = New EditStudent
        oEditStudent.Show()
    End Sub

    Private Sub btnDeleteStudent_Click(sender As Object, e As EventArgs) Handles btnDeleteStudent.Click
        Dim oDeleteStudent = New DeleteStudent()
        oDeleteStudent.Show()
    End Sub
End Class