﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class DeleteStudent
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.panelResults = New System.Windows.Forms.Panel()
        Me.lblResult = New System.Windows.Forms.Label()
        Me.lblSearchTitle = New System.Windows.Forms.Label()
        Me.btnSearch = New System.Windows.Forms.Button()
        Me.lblFname = New System.Windows.Forms.Label()
        Me.lblLname = New System.Windows.Forms.Label()
        Me.txtFname = New System.Windows.Forms.TextBox()
        Me.txtLname = New System.Windows.Forms.TextBox()
        Me.txtUid = New System.Windows.Forms.TextBox()
        Me.lblUid = New System.Windows.Forms.Label()
        Me.btnmsgbxDelete = New System.Windows.Forms.Button()
        Me.lblWarning = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'panelResults
        '
        Me.panelResults.BackColor = System.Drawing.Color.White
        Me.panelResults.Location = New System.Drawing.Point(14, 211)
        Me.panelResults.Name = "panelResults"
        Me.panelResults.Size = New System.Drawing.Size(252, 199)
        Me.panelResults.TabIndex = 61
        '
        'lblResult
        '
        Me.lblResult.AutoSize = True
        Me.lblResult.Location = New System.Drawing.Point(15, 195)
        Me.lblResult.Name = "lblResult"
        Me.lblResult.Size = New System.Drawing.Size(45, 13)
        Me.lblResult.TabIndex = 29
        Me.lblResult.Text = "Results:"
        '
        'lblSearchTitle
        '
        Me.lblSearchTitle.AutoSize = True
        Me.lblSearchTitle.Location = New System.Drawing.Point(12, 9)
        Me.lblSearchTitle.Name = "lblSearchTitle"
        Me.lblSearchTitle.Size = New System.Drawing.Size(193, 13)
        Me.lblSearchTitle.TabIndex = 60
        Me.lblSearchTitle.Text = "Search by ID, Last name, or First name."
        '
        'btnSearch
        '
        Me.btnSearch.Location = New System.Drawing.Point(94, 182)
        Me.btnSearch.Name = "btnSearch"
        Me.btnSearch.Size = New System.Drawing.Size(75, 23)
        Me.btnSearch.TabIndex = 59
        Me.btnSearch.Text = "Search"
        Me.btnSearch.UseVisualStyleBackColor = True
        '
        'lblFname
        '
        Me.lblFname.AutoSize = True
        Me.lblFname.Location = New System.Drawing.Point(15, 129)
        Me.lblFname.Name = "lblFname"
        Me.lblFname.Size = New System.Drawing.Size(57, 13)
        Me.lblFname.TabIndex = 58
        Me.lblFname.Text = "First Name"
        '
        'lblLname
        '
        Me.lblLname.AutoSize = True
        Me.lblLname.Location = New System.Drawing.Point(15, 81)
        Me.lblLname.Name = "lblLname"
        Me.lblLname.Size = New System.Drawing.Size(56, 13)
        Me.lblLname.TabIndex = 57
        Me.lblLname.Text = "Last name"
        '
        'txtFname
        '
        Me.txtFname.Location = New System.Drawing.Point(15, 147)
        Me.txtFname.Margin = New System.Windows.Forms.Padding(2)
        Me.txtFname.Name = "txtFname"
        Me.txtFname.Size = New System.Drawing.Size(206, 20)
        Me.txtFname.TabIndex = 56
        '
        'txtLname
        '
        Me.txtLname.Location = New System.Drawing.Point(15, 99)
        Me.txtLname.Margin = New System.Windows.Forms.Padding(2)
        Me.txtLname.Name = "txtLname"
        Me.txtLname.Size = New System.Drawing.Size(206, 20)
        Me.txtLname.TabIndex = 55
        '
        'txtUid
        '
        Me.txtUid.Location = New System.Drawing.Point(74, 40)
        Me.txtUid.Margin = New System.Windows.Forms.Padding(2)
        Me.txtUid.Name = "txtUid"
        Me.txtUid.Size = New System.Drawing.Size(95, 20)
        Me.txtUid.TabIndex = 54
        '
        'lblUid
        '
        Me.lblUid.AutoSize = True
        Me.lblUid.Location = New System.Drawing.Point(12, 40)
        Me.lblUid.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblUid.Name = "lblUid"
        Me.lblUid.Size = New System.Drawing.Size(55, 13)
        Me.lblUid.TabIndex = 53
        Me.lblUid.Text = "Unique ID"
        '
        'btnmsgbxDelete
        '
        Me.btnmsgbxDelete.Location = New System.Drawing.Point(191, 446)
        Me.btnmsgbxDelete.Name = "btnmsgbxDelete"
        Me.btnmsgbxDelete.Size = New System.Drawing.Size(75, 23)
        Me.btnmsgbxDelete.TabIndex = 62
        Me.btnmsgbxDelete.Text = "Delete"
        Me.btnmsgbxDelete.UseVisualStyleBackColor = True
        '
        'lblWarning
        '
        Me.lblWarning.AutoSize = True
        Me.lblWarning.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblWarning.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.lblWarning.Location = New System.Drawing.Point(12, 445)
        Me.lblWarning.Name = "lblWarning"
        Me.lblWarning.Size = New System.Drawing.Size(133, 24)
        Me.lblWarning.TabIndex = 40
        Me.lblWarning.Text = "If Students.xlsx is open, please" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "close it before clicking Delete." & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        '
        'DeleteStudent
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.AutoScroll = True
        Me.ClientSize = New System.Drawing.Size(310, 499)
        Me.Controls.Add(Me.lblWarning)
        Me.Controls.Add(Me.lblResult)
        Me.Controls.Add(Me.btnmsgbxDelete)
        Me.Controls.Add(Me.panelResults)
        Me.Controls.Add(Me.lblSearchTitle)
        Me.Controls.Add(Me.btnSearch)
        Me.Controls.Add(Me.lblFname)
        Me.Controls.Add(Me.lblLname)
        Me.Controls.Add(Me.txtFname)
        Me.Controls.Add(Me.txtLname)
        Me.Controls.Add(Me.txtUid)
        Me.Controls.Add(Me.lblUid)
        Me.Name = "DeleteStudent"
        Me.Text = "Delete a student"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents panelResults As Panel
    Friend WithEvents lblResult As Label
    Friend WithEvents lblSearchTitle As Label
    Friend WithEvents btnSearch As Button
    Friend WithEvents lblFname As Label
    Friend WithEvents lblLname As Label
    Friend WithEvents txtFname As TextBox
    Friend WithEvents txtLname As TextBox
    Friend WithEvents txtUid As TextBox
    Friend WithEvents lblUid As Label
    Friend WithEvents btnmsgbxDelete As Button
    Friend WithEvents lblWarning As Label
End Class
