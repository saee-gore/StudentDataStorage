﻿Imports Excel = Microsoft.Office.Interop.Excel

Public Module Control 'Module = static class
    Public Function FilePathStudentsXlsx() As String
        Return (My.Application.Info.DirectoryPath & "\..\..\Students.xlsx")
    End Function

    Public Function openExcelProgram() As Excel.Worksheet
        Dim filePath As String = Control.FilePathStudentsXlsx()
        Dim openExcel = CreateObject("Excel.Application")
        openExcel.Workbooks.Open(filePath)
        Dim openWorkBook As Excel.Workbook = openExcel.ActiveWorkbook
        Dim openWorkSheet As Excel.Worksheet = openExcel.Worksheets(1)
        Return openWorkSheet
    End Function

    Public Function closeExcelProgram(worksheet As Excel.Worksheet, save As Boolean) As String
        Dim filePath As String = Control.FilePathStudentsXlsx()
        Dim excelApp As Excel.Application = worksheet.Application
        excelApp.DisplayAlerts = False
        If save Then
            Try
                excelApp.ActiveWorkbook.SaveAs(filePath)
            Catch
                excelApp.ActiveWorkbook.Close()
                Return "Error: Unable to save because another instance of the worksheet is already open"
                'It is best to display this return value in a message box.
            End Try
        End If
        excelApp.ActiveWorkbook.Close()
        Return "Closed sheet"
    End Function

    Public Function deleteRow(rowNum As Integer) As String
        Dim excel As Excel.Worksheet = openExcelProgram()
        Try
            excel.Rows(rowNum).EntireRow.Delete()
        Catch
            Return "An error occurred trying to delete that row"
        End Try
        closeExcelProgram(excel, True)
        Return "Successfully deleted row"
    End Function

    Public Sub FindStudents(uid As String, lName As String, fName As String, ByRef panel As Panel)
        'In worksheet, find all rows matching Unique ID uid, Last Name lName, and First Name
        'fName. If one of those fields is empty, only search by the others. For each matching
        'row, place a RadioButton representing that row in panel.
        'This subroutine should be used in EditStudent and DeleteStudent forms.

        panel.Controls.Clear()

        uid = uid.ToUpper
        lName = lName.ToUpper
        fName = fName.ToUpper

        Dim openWorkSheet As Excel.Worksheet = openExcelProgram()

        Dim numFound As Integer = 0
        Dim r As Integer = 2 'row index
        Dim rowFields = openWorkSheet.Range("B" & r).Resize(1, 3).Value
        'rowFields = {Unique ID, Last Name, First Name} for row r (columns {B,C,D})

        While (Not (IsNothing(rowFields(1, 1)) OrElse IsNothing(rowFields(1, 2)) OrElse IsNothing(rowFields(1, 3))))
            'If one of these cells is empty, assume that the previous row was the last one
            'containing a valid student, and exit search loop
            If (String.IsNullOrEmpty(uid) OrElse uid = rowFields(1, 1).ToString.ToUpper) Then
                If (String.IsNullOrEmpty(lName) OrElse lName = rowFields(1, 2).ToString.ToUpper) Then
                    If (String.IsNullOrEmpty(fName) OrElse fName = rowFields(1, 3).ToString.ToUpper) Then
                        'The row matches the search!
                        Dim rbStudent As RadioButton = New RadioButton
                        rbStudent.Text = String.Format("Row: {0} | ID: {1} | Name: {2}, {3}",
                            r, rowFields(1, 1), rowFields(1, 2), rowFields(1, 3))
                        rbStudent.AutoSize = True
                        rbStudent.Top = 20 * numFound
                        rbStudent.Name = "rbStudentRow" & r
                        Console.WriteLine(rbStudent.Name)
                        panel.Controls.Add(rbStudent)
                        numFound += 1
                    End If
                End If
            End If
            r += 1
            rowFields = openWorkSheet.Range("B" & r).Resize(1, 3).Value
        End While

        closeExcelProgram(openWorkSheet, False)
        'false parameter above: Do not save, since worksheet was only read, not written
        'to .This prevents errors if worksheet was opened in read-only mode.
    End Sub
End Module
