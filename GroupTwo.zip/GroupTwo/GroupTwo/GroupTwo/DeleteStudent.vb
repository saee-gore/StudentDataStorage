﻿Public Class DeleteStudent
    Private Sub btnSearch_Click(sender As Object, e As EventArgs) Handles btnSearch.Click
        Control.FindStudents(txtUid.Text, txtLname.Text, txtFname.Text, panelResults)
    End Sub

    Private Sub btnmsgbxDelete_Click(sender As Object, e As EventArgs) Handles btnmsgbxDelete.Click
        Dim buttonClicked As Boolean = False
        Dim row As Integer
        For Each Ctrl In panelResults.Controls
            If Ctrl.Checked Then
                row = panelResults.Controls.GetChildIndex(Ctrl) + 2
                'Child index starts at 0; our rows start at 2
                buttonClicked = True
                Exit For
            End If
        Next
        If Not buttonClicked Then
            MessageBox.Show("Please select a student to delete from the results menu.")
            Exit Sub
        End If
        Dim result As DialogResult =
            MessageBox.Show("Are you sure you want to delete this student?", "Warning", MessageBoxButtons.YesNo)
        If result = DialogResult.Yes Then
            MessageBox.Show(Control.deleteRow(row), "Result", MessageBoxButtons.OK)
            Control.FindStudents(txtUid.Text, txtLname.Text, txtFname.Text, panelResults)
        End If
    End Sub

    Private Sub txtUid_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtUid.KeyPress
        If (Asc(e.KeyChar) >= 48 And Asc(e.KeyChar) <= 57) Or Asc(e.KeyChar) = 8 Then
            e.Handled = False

        Else
            e.Handled = True
        End If
    End Sub
End Class