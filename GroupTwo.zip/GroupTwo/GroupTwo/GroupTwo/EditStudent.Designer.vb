﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class EditStudent
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.txtFname = New System.Windows.Forms.TextBox()
        Me.txtLname = New System.Windows.Forms.TextBox()
        Me.txtUid = New System.Windows.Forms.TextBox()
        Me.lblUid = New System.Windows.Forms.Label()
        Me.lblLname = New System.Windows.Forms.Label()
        Me.lblFname = New System.Windows.Forms.Label()
        Me.btnSearch = New System.Windows.Forms.Button()
        Me.lblResult = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.lblCnumber = New System.Windows.Forms.Label()
        Me.lblYear = New System.Windows.Forms.Label()
        Me.lblMajor = New System.Windows.Forms.Label()
        Me.txtYear = New System.Windows.Forms.TextBox()
        Me.txtMajor = New System.Windows.Forms.TextBox()
        Me.lblCearned = New System.Windows.Forms.Label()
        Me.lblGpa = New System.Windows.Forms.Label()
        Me.lblTuition = New System.Windows.Forms.Label()
        Me.lblScholarship = New System.Windows.Forms.Label()
        Me.btnSubmitChanges = New System.Windows.Forms.Button()
        Me.txtCearned = New System.Windows.Forms.TextBox()
        Me.txtGpa = New System.Windows.Forms.TextBox()
        Me.txtTuition = New System.Windows.Forms.TextBox()
        Me.txtScholarship = New System.Windows.Forms.TextBox()
        Me.lblSearchTitle = New System.Windows.Forms.Label()
        Me.Splitter1 = New System.Windows.Forms.Splitter()
        Me.panelResults = New System.Windows.Forms.Panel()
        Me.lblWarning = New System.Windows.Forms.Label()
        Me.txtCnumber = New System.Windows.Forms.MaskedTextBox()
        Me.SuspendLayout()
        '
        'txtFname
        '
        Me.txtFname.Location = New System.Drawing.Point(12, 147)
        Me.txtFname.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.txtFname.Name = "txtFname"
        Me.txtFname.Size = New System.Drawing.Size(206, 20)
        Me.txtFname.TabIndex = 24
        '
        'txtLname
        '
        Me.txtLname.Location = New System.Drawing.Point(12, 99)
        Me.txtLname.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.txtLname.Name = "txtLname"
        Me.txtLname.Size = New System.Drawing.Size(206, 20)
        Me.txtLname.TabIndex = 23
        '
        'txtUid
        '
        Me.txtUid.Location = New System.Drawing.Point(71, 40)
        Me.txtUid.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.txtUid.Name = "txtUid"
        Me.txtUid.Size = New System.Drawing.Size(95, 20)
        Me.txtUid.TabIndex = 22
        '
        'lblUid
        '
        Me.lblUid.AutoSize = True
        Me.lblUid.Location = New System.Drawing.Point(9, 40)
        Me.lblUid.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblUid.Name = "lblUid"
        Me.lblUid.Size = New System.Drawing.Size(55, 13)
        Me.lblUid.TabIndex = 21
        Me.lblUid.Text = "Unique ID"
        '
        'lblLname
        '
        Me.lblLname.AutoSize = True
        Me.lblLname.Location = New System.Drawing.Point(12, 81)
        Me.lblLname.Name = "lblLname"
        Me.lblLname.Size = New System.Drawing.Size(56, 13)
        Me.lblLname.TabIndex = 26
        Me.lblLname.Text = "Last name"
        '
        'lblFname
        '
        Me.lblFname.AutoSize = True
        Me.lblFname.Location = New System.Drawing.Point(12, 129)
        Me.lblFname.Name = "lblFname"
        Me.lblFname.Size = New System.Drawing.Size(57, 13)
        Me.lblFname.TabIndex = 27
        Me.lblFname.Text = "First Name"
        '
        'btnSearch
        '
        Me.btnSearch.Location = New System.Drawing.Point(91, 182)
        Me.btnSearch.Name = "btnSearch"
        Me.btnSearch.Size = New System.Drawing.Size(75, 23)
        Me.btnSearch.TabIndex = 28
        Me.btnSearch.Text = "Search"
        Me.btnSearch.UseVisualStyleBackColor = True
        '
        'lblResult
        '
        Me.lblResult.AutoSize = True
        Me.lblResult.Location = New System.Drawing.Point(15, 209)
        Me.lblResult.Name = "lblResult"
        Me.lblResult.Size = New System.Drawing.Size(45, 13)
        Me.lblResult.TabIndex = 29
        Me.lblResult.Text = "Results:"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(12, 413)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(80, 13)
        Me.Label6.TabIndex = 34
        Me.Label6.Text = "Edit Information"
        '
        'lblCnumber
        '
        Me.lblCnumber.AutoSize = True
        Me.lblCnumber.Location = New System.Drawing.Point(12, 443)
        Me.lblCnumber.Name = "lblCnumber"
        Me.lblCnumber.Size = New System.Drawing.Size(38, 13)
        Me.lblCnumber.TabIndex = 35
        Me.lblCnumber.Text = "Phone"
        '
        'lblYear
        '
        Me.lblYear.AutoSize = True
        Me.lblYear.Location = New System.Drawing.Point(12, 474)
        Me.lblYear.Name = "lblYear"
        Me.lblYear.Size = New System.Drawing.Size(78, 13)
        Me.lblYear.TabIndex = 36
        Me.lblYear.Text = "Year in College"
        '
        'lblMajor
        '
        Me.lblMajor.AutoSize = True
        Me.lblMajor.Location = New System.Drawing.Point(12, 496)
        Me.lblMajor.Name = "lblMajor"
        Me.lblMajor.Size = New System.Drawing.Size(33, 13)
        Me.lblMajor.TabIndex = 37
        Me.lblMajor.Text = "Major"
        '
        'txtYear
        '
        Me.txtYear.Location = New System.Drawing.Point(96, 471)
        Me.txtYear.Name = "txtYear"
        Me.txtYear.Size = New System.Drawing.Size(166, 20)
        Me.txtYear.TabIndex = 39
        '
        'txtMajor
        '
        Me.txtMajor.Location = New System.Drawing.Point(15, 513)
        Me.txtMajor.Name = "txtMajor"
        Me.txtMajor.Size = New System.Drawing.Size(248, 20)
        Me.txtMajor.TabIndex = 40
        '
        'lblCearned
        '
        Me.lblCearned.AutoSize = True
        Me.lblCearned.Location = New System.Drawing.Point(20, 553)
        Me.lblCearned.Name = "lblCearned"
        Me.lblCearned.Size = New System.Drawing.Size(134, 13)
        Me.lblCearned.TabIndex = 41
        Me.lblCearned.Text = "Credits earned at institution"
        '
        'lblGpa
        '
        Me.lblGpa.AutoSize = True
        Me.lblGpa.Location = New System.Drawing.Point(125, 579)
        Me.lblGpa.Name = "lblGpa"
        Me.lblGpa.Size = New System.Drawing.Size(29, 13)
        Me.lblGpa.TabIndex = 42
        Me.lblGpa.Text = "GPA"
        '
        'lblTuition
        '
        Me.lblTuition.AutoSize = True
        Me.lblTuition.Location = New System.Drawing.Point(12, 611)
        Me.lblTuition.Name = "lblTuition"
        Me.lblTuition.Size = New System.Drawing.Size(142, 13)
        Me.lblTuition.TabIndex = 43
        Me.lblTuition.Text = "Tuition before scholarships $"
        '
        'lblScholarship
        '
        Me.lblScholarship.AutoSize = True
        Me.lblScholarship.Location = New System.Drawing.Point(78, 637)
        Me.lblScholarship.Name = "lblScholarship"
        Me.lblScholarship.Size = New System.Drawing.Size(76, 13)
        Me.lblScholarship.TabIndex = 44
        Me.lblScholarship.Text = "Scholarships $"
        '
        'btnSubmitChanges
        '
        Me.btnSubmitChanges.Location = New System.Drawing.Point(163, 666)
        Me.btnSubmitChanges.Name = "btnSubmitChanges"
        Me.btnSubmitChanges.Size = New System.Drawing.Size(100, 23)
        Me.btnSubmitChanges.TabIndex = 45
        Me.btnSubmitChanges.Text = "Submit Changes"
        Me.btnSubmitChanges.UseVisualStyleBackColor = True
        '
        'txtCearned
        '
        Me.txtCearned.Location = New System.Drawing.Point(163, 550)
        Me.txtCearned.Name = "txtCearned"
        Me.txtCearned.Size = New System.Drawing.Size(100, 20)
        Me.txtCearned.TabIndex = 46
        '
        'txtGpa
        '
        Me.txtGpa.Location = New System.Drawing.Point(163, 576)
        Me.txtGpa.Name = "txtGpa"
        Me.txtGpa.Size = New System.Drawing.Size(100, 20)
        Me.txtGpa.TabIndex = 47
        '
        'txtTuition
        '
        Me.txtTuition.Location = New System.Drawing.Point(163, 608)
        Me.txtTuition.Name = "txtTuition"
        Me.txtTuition.Size = New System.Drawing.Size(98, 20)
        Me.txtTuition.TabIndex = 48
        '
        'txtScholarship
        '
        Me.txtScholarship.Location = New System.Drawing.Point(163, 634)
        Me.txtScholarship.Name = "txtScholarship"
        Me.txtScholarship.Size = New System.Drawing.Size(98, 20)
        Me.txtScholarship.TabIndex = 49
        '
        'lblSearchTitle
        '
        Me.lblSearchTitle.AutoSize = True
        Me.lblSearchTitle.Location = New System.Drawing.Point(9, 9)
        Me.lblSearchTitle.Name = "lblSearchTitle"
        Me.lblSearchTitle.Size = New System.Drawing.Size(193, 13)
        Me.lblSearchTitle.TabIndex = 50
        Me.lblSearchTitle.Text = "Search by ID, Last name, or First name."
        '
        'Splitter1
        '
        Me.Splitter1.Location = New System.Drawing.Point(0, 0)
        Me.Splitter1.Name = "Splitter1"
        Me.Splitter1.Size = New System.Drawing.Size(3, 702)
        Me.Splitter1.TabIndex = 51
        Me.Splitter1.TabStop = False
        '
        'panelResults
        '
        Me.panelResults.BackColor = System.Drawing.Color.White
        Me.panelResults.Location = New System.Drawing.Point(11, 225)
        Me.panelResults.Name = "panelResults"
        Me.panelResults.Size = New System.Drawing.Size(252, 185)
        Me.panelResults.TabIndex = 52
        '
        'lblWarning
        '
        Me.lblWarning.AutoSize = True
        Me.lblWarning.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblWarning.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.lblWarning.Location = New System.Drawing.Point(21, 666)
        Me.lblWarning.Name = "lblWarning"
        Me.lblWarning.Size = New System.Drawing.Size(109, 36)
        Me.lblWarning.TabIndex = 53
        Me.lblWarning.Text = "If Students.xlsx is open," & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "please close it before" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "clicking Submit Changes." & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        '
        'txtCnumber
        '
        Me.txtCnumber.Location = New System.Drawing.Point(96, 440)
        Me.txtCnumber.Mask = "(999) 000-0000"
        Me.txtCnumber.Name = "txtCnumber"
        Me.txtCnumber.Size = New System.Drawing.Size(165, 20)
        Me.txtCnumber.TabIndex = 54
        '
        'EditStudent
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.AutoScroll = True
        Me.ClientSize = New System.Drawing.Size(298, 609)
        Me.Controls.Add(Me.txtCnumber)
        Me.Controls.Add(Me.lblWarning)
        Me.Controls.Add(Me.lblResult)
        Me.Controls.Add(Me.panelResults)
        Me.Controls.Add(Me.Splitter1)
        Me.Controls.Add(Me.lblSearchTitle)
        Me.Controls.Add(Me.txtScholarship)
        Me.Controls.Add(Me.txtTuition)
        Me.Controls.Add(Me.txtGpa)
        Me.Controls.Add(Me.txtCearned)
        Me.Controls.Add(Me.btnSubmitChanges)
        Me.Controls.Add(Me.lblScholarship)
        Me.Controls.Add(Me.lblTuition)
        Me.Controls.Add(Me.lblGpa)
        Me.Controls.Add(Me.lblCearned)
        Me.Controls.Add(Me.txtMajor)
        Me.Controls.Add(Me.txtYear)
        Me.Controls.Add(Me.lblMajor)
        Me.Controls.Add(Me.lblYear)
        Me.Controls.Add(Me.lblCnumber)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.btnSearch)
        Me.Controls.Add(Me.lblFname)
        Me.Controls.Add(Me.lblLname)
        Me.Controls.Add(Me.txtFname)
        Me.Controls.Add(Me.txtLname)
        Me.Controls.Add(Me.txtUid)
        Me.Controls.Add(Me.lblUid)
        Me.Name = "EditStudent"
        Me.Text = "Edit a student"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents txtFname As TextBox
    Friend WithEvents txtLname As TextBox
    Friend WithEvents txtUid As TextBox
    Friend WithEvents lblUid As Label
    Friend WithEvents lblLname As Label
    Friend WithEvents lblFname As Label
    Friend WithEvents btnSearch As Button
    Friend WithEvents lblResult As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents lblCnumber As Label
    Friend WithEvents lblYear As Label
    Friend WithEvents lblMajor As Label
    Friend WithEvents txtYear As TextBox
    Friend WithEvents txtMajor As TextBox
    Friend WithEvents lblCearned As Label
    Friend WithEvents lblGpa As Label
    Friend WithEvents lblTuition As Label
    Friend WithEvents lblScholarship As Label
    Friend WithEvents btnSubmitChanges As Button
    Friend WithEvents txtCearned As TextBox
    Friend WithEvents txtGpa As TextBox
    Friend WithEvents txtTuition As TextBox
    Friend WithEvents txtScholarship As TextBox
    Friend WithEvents lblSearchTitle As Label
    Friend WithEvents Splitter1 As Splitter
    Friend WithEvents panelResults As Panel
    Friend WithEvents lblWarning As Label
    Friend WithEvents txtCnumber As MaskedTextBox
End Class
