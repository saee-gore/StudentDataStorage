﻿Imports Excel = Microsoft.Office.Interop.Excel
Public Class EditStudent

    Private Sub btnSearch_Click(sender As Object, e As EventArgs) Handles btnSearch.Click
        Control.FindStudents(uid:=txtUid.Text, lName:=txtLname.Text, fName:=txtFname.Text, panel:=panelResults)
    End Sub

    Private Sub btnSubmitChanges_Click(sender As Object, e As EventArgs) Handles btnSubmitChanges.Click

        Dim buttonClicked As Boolean = False
        Dim row As Integer
        For Each Ctrl In panelResults.Controls
            If Ctrl.Checked Then
                row = panelResults.Controls.GetChildIndex(Ctrl) + 2
                'Child index starts at 0; our rows start at 2
                buttonClicked = True
                Exit For
            End If
        Next
        If Not buttonClicked Then
            MessageBox.Show("Please select a student to edit from the results menu.")
            Exit Sub
        End If
        Dim r As String = row

        Dim openWorkSheet As Excel.Worksheet = Control.openExcelProgram()

        If String.IsNullOrEmpty(txtGpa.Text) Then
            'do nothing
        Else
            Dim gpavalue As Double = txtGpa.Text
            If gpavalue < 0 OrElse gpavalue > 4 Then
                Control.closeExcelProgram(openWorkSheet, False)
                MsgBox("GPA Value is not valid, make sure it's in range 0 to 4.")
                Exit Sub
            End If
            openWorkSheet.Range("R" & r).Value = gpavalue
        End If

        If String.IsNullOrEmpty(txtCnumber.Text) Then
            'do nothing
        Else
            Dim cnumbervalue As String = txtCnumber.Text
            openWorkSheet.Range("G" & r).Value = cnumbervalue
        End If

        If String.IsNullOrEmpty(txtYear.Text) Then
            'do nothing
        Else
            Dim yearvalue As String = txtYear.Text
            openWorkSheet.Range("K" & r).Value = yearvalue
        End If

        If String.IsNullOrEmpty(txtMajor.Text) Then
            'do nothing
        Else
            Dim majorvalue As String = txtMajor.Text
            openWorkSheet.Range("L" & r).Value = majorvalue
        End If

        If String.IsNullOrEmpty(txtCearned.Text) Then
            'do nothing
        Else
            Dim cearnvalue As Integer = txtCearned.Text
            If cearnvalue < 0 Then
                Control.closeExcelProgram(openWorkSheet, False)
                MsgBox("Credits Earned Value is not valid, make sure it's not negative.")
                Exit Sub
            End If
            openWorkSheet.Range("P" & r).Value = cearnvalue
        End If

        If String.IsNullOrEmpty(txtTuition.Text) Then
            'do nothing
        Else
            Dim tuitionvalue As Integer = txtTuition.Text
            If tuitionvalue < 0 Then
                Control.closeExcelProgram(openWorkSheet, False)
                MsgBox("Tution Value is not valid, make sure it's not negative.")
                Exit Sub
            End If
            openWorkSheet.Range("T" & r).Value = tuitionvalue
        End If

        If String.IsNullOrEmpty(txtScholarship.Text) Then
            'do nothing
        Else
            Dim scholarshipvalue As Integer = txtScholarship.Text
            If scholarshipvalue < 0 Then
                Control.closeExcelProgram(openWorkSheet, False)
                MsgBox("Scholarship Value is not valid, make sure it's not negative.")
                Exit Sub
            End If
            openWorkSheet.Range("U" & r).Value = scholarshipvalue
        End If

        Control.closeExcelProgram(openWorkSheet, True)

    End Sub

    'events
    Private Sub txtUid_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtUid.KeyPress
        If (Asc(e.KeyChar) >= 48 And Asc(e.KeyChar) <= 57) Or Asc(e.KeyChar) = 8 Then
            e.Handled = False
        Else
            e.Handled = True
        End If
    End Sub

    Private Sub txtCnumber_KeyPress(sender As Object, e As KeyPressEventArgs)
        If (Asc(e.KeyChar) >= 48 And Asc(e.KeyChar) <= 57) Or Asc(e.KeyChar) = 8 Or Asc(e.KeyChar) = 43 Or Asc(e.KeyChar) = 40 Or Asc(e.KeyChar) = 41 Or Asc(e.KeyChar) = 45 Then
            e.Handled = False

        Else
            e.Handled = True
        End If
    End Sub

    Private Sub txtCearned_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtCearned.KeyPress
        If (Asc(e.KeyChar) >= 48 And Asc(e.KeyChar) <= 57) Or Asc(e.KeyChar) = 8 Then
            e.Handled = False

        Else
            e.Handled = True
        End If

    End Sub

    Private Sub txtGpa_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtGpa.KeyPress
        If (Asc(e.KeyChar) >= 48 And Asc(e.KeyChar) <= 57) Or Asc(e.KeyChar) = 8 Or Asc(e.KeyChar) = 46 Then
            e.Handled = False

        Else
            e.Handled = True
        End If
    End Sub

    Private Sub txtTuition_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtTuition.KeyPress
        If (Asc(e.KeyChar) >= 48 And Asc(e.KeyChar) <= 57) Or Asc(e.KeyChar) = 8 Or Asc(e.KeyChar) = 44 Then
            e.Handled = False

        Else
            e.Handled = True
        End If
    End Sub

    Private Sub txtScholarship_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtScholarship.KeyPress
        If (Asc(e.KeyChar) >= 48 And Asc(e.KeyChar) <= 57) Or Asc(e.KeyChar) = 8 Or Asc(e.KeyChar) = 44 Then
            e.Handled = False

        Else
            e.Handled = True
        End If
    End Sub
End Class