﻿Imports Excel = Microsoft.Office.Interop.Excel
Public Class NewStudent
    Private Sub btnSuggest_Click(sender As Object, e As EventArgs) Handles btnSuggest.Click
        ' Suggests an email address from first, middle, and last names, and places suggestion in txtUemail

        If String.IsNullOrEmpty(txtLname.Text) OrElse String.IsNullOrEmpty(txtFname.Text) Then
            MessageBox.Show(
                "Please enter your first and last name before requesting an email address suggestion")
            txtUemail.Text = String.Empty
            Exit Sub
        End If
        Dim suggestion As String = txtFname.Text(0)
        'Unlike first and last names, middle name can be empty
        If Not String.IsNullOrEmpty(txtMname.Text) Then
            suggestion &= txtMname.Text(0)
        End If
        suggestion &= txtLname.Text
        suggestion = suggestion.ToLower
        txtUemail.Text = suggestion
    End Sub

    Private Sub btnSubmit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSubmit.Click

        If (String.IsNullOrEmpty(txtUid.Text) OrElse
            String.IsNullOrEmpty(txtLname.Text) OrElse
            String.IsNullOrEmpty(txtFname.Text) OrElse
            String.IsNullOrEmpty(txtUemail.Text)
        ) Then
            MessageBox.Show(
                "One or more of the required (starred) fields are not filled in:" & Environment.NewLine &
                "*Unique ID, *Last name, *First name, *University email")
            Exit Sub
        End If

        Dim uidvalue As Integer = txtUid.Text
        Dim lnamevalue As String = txtLname.Text
        Dim fnamevalue As String = txtFname.Text
        Dim mnamevalue As String = txtMname.Text
        Dim uemail As String = txtUemail.Text & "@usca.edu"
        Dim cnumbervalue As String = txtCnumber.Text
        Dim dstring As String = dtpDate.Value.ToShortDateString
        Dim ethnicityvalue As String = txtEthnicity.Text
        Dim yearvalue As String = txtYear.Text
        Dim majorvalue As String = txtMajor.Text
        Dim ctransfervalue As Integer =
            If(String.IsNullOrEmpty(txtCtransfer.Text), Nothing, txtCtransfer.Text)
        Dim cearnvalue As Integer =
            If(String.IsNullOrEmpty(txtCearned.Text), Nothing, txtCearned.Text)
        Dim gpavalue As Double =
            If(String.IsNullOrEmpty(txtGpa.Text), Nothing, txtGpa.Text)
        Dim tuitionvalue As Integer =
            If(String.IsNullOrEmpty(txtTuition.Text), Nothing, txtTuition.Text)
        Dim scholarshipvalue As Integer =
            If(String.IsNullOrEmpty(txtScholarship.Text), Nothing, txtScholarship.Text)

        If uidvalue <> Nothing AndAlso uidvalue < 0 Then
            MsgBox("UID Value is not valid, make sure it's not negative.")
            Exit Sub
        End If

        If ctransfervalue <> Nothing AndAlso ctransfervalue < 0 Then
            MsgBox("Credits Transfer Value is not valid, make sure it's not negative.")
            Exit Sub
        End If

        If cearnvalue <> Nothing AndAlso cearnvalue < 0 Then
            MsgBox("Creadits Earned Value is not valid, make sure it's not negative.")
            Exit Sub
        End If

        If gpavalue <> Nothing AndAlso (gpavalue < 0 OrElse gpavalue > 4) Then
            MsgBox("GPA Value is not valid, make sure it's in range 0 to 4.")
            Exit Sub
        End If

        If tuitionvalue <> Nothing AndAlso tuitionvalue < 0 Then
            MsgBox("Tution Value is not valid, make sure it's not negative.")
            Exit Sub
        End If

        If scholarshipvalue <> Nothing AndAlso scholarshipvalue < 0 Then
            MsgBox("Scholarship Value is not valid, make sure it's not negative.")
            Exit Sub
        End If

        Dim openWorkSheet As Excel.Worksheet = Control.openExcelProgram()
        openWorkSheet.Rows(2).EntireRow.Insert()


        'modifying values

        openWorkSheet.Range("B2").Value = uidvalue
        openWorkSheet.Range("C2").Value = lnamevalue
        openWorkSheet.Range("D2").Value = fnamevalue
        openWorkSheet.Range("E2").Value = mnamevalue
        openWorkSheet.Range("F2").Value = dstring
        openWorkSheet.Range("G2").Value = cnumbervalue
        openWorkSheet.Range("H2").Value = uemail

        If rbMale.Checked Then
            openWorkSheet.Range("I2").Value = "Male"
        ElseIf rbFemale.Checked Then
            openWorkSheet.Range("I2").Value = "Female"
        ElseIf rbOther.Checked Then
            openWorkSheet.Range("I2").Value = "Other"
        End If

        openWorkSheet.Range("J2").Value = ethnicityvalue
        openWorkSheet.Range("K2").Value = yearvalue
        openWorkSheet.Range("L2").Value = majorvalue

        If cbIstudent.CheckState = CheckState.Checked Then
            openWorkSheet.Range("M2").Value = "Yes"
        Else
            openWorkSheet.Range("M2").Value = "No"
        End If

        If cbTstudent.CheckState = CheckState.Checked Then
            openWorkSheet.Range("N2").Value = "Yes"
        Else
            openWorkSheet.Range("N2").Value = "No"
        End If

        If ctransfervalue <> Nothing Then
            openWorkSheet.Range("O2").Value = ctransfervalue
        End If
        If cearnvalue <> Nothing Then
            openWorkSheet.Range("P2").Value = cearnvalue
        End If
        openWorkSheet.Range("Q2").Formula = "=MAX(0,120-O2-P2)"
        If gpavalue <> Nothing Then
            openWorkSheet.Range("R2").Value = gpavalue
        End If
        openWorkSheet.Range("S2").Formula = "=(R2*(O2+P2)/120) + (4*Q2/120)"
        If tuitionvalue <> Nothing Then
            openWorkSheet.Range("T2").Value = tuitionvalue
        End If
        If scholarshipvalue <> Nothing Then
            openWorkSheet.Range("U2").Value = scholarshipvalue
        End If
        openWorkSheet.Range("V2").Formula = "=T2-U2"

        'save
        Control.closeExcelProgram(openWorkSheet, True)

    End Sub

    'The uid textbox will now only accept numbers And backspace can be used While typing by user
    'ASCII code for 0 to 9 is from 48 to 57 and for backspace is 8
    Private Sub txtUid_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtUid.KeyPress
        If (Asc(e.KeyChar) >= 48 And Asc(e.KeyChar) <= 57) Or Asc(e.KeyChar) = 8 Then
            e.Handled = False

        Else
            e.Handled = True
        End If
    End Sub

    'ASCII code for : '+' = 43,'(' = 40,')'= 41, '-'=45, 
    Private Sub txtCnumber_KeyPress(sender As Object, e As KeyPressEventArgs)
        If (Asc(e.KeyChar) >= 48 And Asc(e.KeyChar) <= 57) Or Asc(e.KeyChar) = 8 Or Asc(e.KeyChar) = 43 Or Asc(e.KeyChar) = 40 Or Asc(e.KeyChar) = 41 Or Asc(e.KeyChar) = 45 Then
            e.Handled = False

        Else
            e.Handled = True
        End If


    End Sub

    Private Sub txtCtransfer_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtCtransfer.KeyPress
        If (Asc(e.KeyChar) >= 48 And Asc(e.KeyChar) <= 57) Or Asc(e.KeyChar) = 8 Then
            e.Handled = False

        Else
            e.Handled = True
        End If

    End Sub

    Private Sub txtCearned_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtCearned.KeyPress
        If (Asc(e.KeyChar) >= 48 And Asc(e.KeyChar) <= 57) Or Asc(e.KeyChar) = 8 Then
            e.Handled = False

        Else
            e.Handled = True
        End If

    End Sub
    'ASCII code for : '.' = 46
    Private Sub txtGpa_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtGpa.KeyPress
        If (Asc(e.KeyChar) >= 48 And Asc(e.KeyChar) <= 57) Or Asc(e.KeyChar) = 8 Or Asc(e.KeyChar) = 46 Then
            e.Handled = False

        Else
            e.Handled = True
        End If
    End Sub
    'ASCII code for : ',' = 44
    Private Sub txtTuition_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtTuition.KeyPress
        If (Asc(e.KeyChar) >= 48 And Asc(e.KeyChar) <= 57) Or Asc(e.KeyChar) = 8 Or Asc(e.KeyChar) = 44 Then
            e.Handled = False

        Else
            e.Handled = True
        End If
    End Sub

    Private Sub txtScholarship_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtScholarship.KeyPress
        If (Asc(e.KeyChar) >= 48 And Asc(e.KeyChar) <= 57) Or Asc(e.KeyChar) = 8 Or Asc(e.KeyChar) = 44 Then
            e.Handled = False

        Else
            e.Handled = True
        End If
    End Sub
End Class
